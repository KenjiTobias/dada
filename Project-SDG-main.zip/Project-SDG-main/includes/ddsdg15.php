<div class="dropdown">
            <button class="btn btn-outline-dark dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                Pick a research
            </button>
            <ul class="dropdown-menu bg-white border-0 " aria-labelledby="dropdownMenuButton1">
                <li class="text-center"><button class="btn btn-dark w-100 mb-2" id="res1511"> Research on land ecosystems</button></li>
                <li class="text-center"><button class="btn btn-dark w-100 mb-2" id="res1521"> Measures that promote sustainable land practices: Students</button></li>
                <li class="text-center"><button class="btn btn-dark w-100 mb-2" id="res15212"> Measures that promote sustainable land practices: Employees</button></li>
                <li class="text-center"><button class="btn btn-dark w-100 mb-2" id="res1531"> Number of endangered flora/fauna in the campus</button></li>
                <li class="text-center"><button class="btn btn-dark w-100 mb-2" id="res1532"> Measures to conserve the endangered species</button></li>
                <li class="text-center"><button class="btn btn-dark w-100 mb-2" id="res1541"> Events about sustainable use of land</button></li>
                <li class="text-center"><button class="btn btn-dark w-100 mb-2" id="res1542"> Sustainably farmed food on campus</button></li>
                <li class="text-center"><button class="btn btn-dark w-100 mb-2" id="res1543"> Maintain and extend current ecosystems’ biodiversity</button></li>
                <li class="text-center"><button class="btn btn-dark w-100 mb-2" id="res1551"> Biodiversity in the community</button></li>
            </ul>
        </div>

       